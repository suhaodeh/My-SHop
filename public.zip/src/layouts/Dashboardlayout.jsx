import React from 'react'

export default function Dashboardlayout() {
  return (
    <div>layout</div>
  )
}
