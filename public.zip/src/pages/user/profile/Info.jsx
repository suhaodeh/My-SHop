import React, { useContext } from 'react'
import { UserContext } from '../context/UserContext';

export default function Info() {
    const {user,loading}= useContext(UserContext);
  return (
    <div className='ps-5 ms-5'>
        <h2 className='ps-5'>Name is {user.userName}</h2>
        <h3 className='ps-5'>Email is {user.email}</h3>
    </div>
  )
}
