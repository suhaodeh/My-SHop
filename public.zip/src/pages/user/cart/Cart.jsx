import React, { useEffect, useState } from 'react'
import axios from 'axios';
import Table from 'react-bootstrap/Table';
import { Button } from 'bootstrap';
import { Link } from 'react-router-dom';
export default function Cart() {
  const [cart,setCart]= useState(null);
  const[isLoading,setisIoading]=useState(true);


  const getCart =async()=>{
    try{
      const token= localStorage.getItem('userToken');
      const response =await axios.get("https://ecommerce-node4.onrender.com/cart",
        {
          headers:{
 Authorization: `Tariq__${token}`
          }
         
        }
      );
      console.log(response);
      setCart(response.data.products);
      console.log(response.data);

    }catch(error){
console.log("error",error);
    }finally{
      setisIoading(false);
    }
  }
  useEffect( ()=>{
    getCart();
  },[])
  if(isLoading){ return <h2>Loading...</h2>}

  const incQty=async(productId)=>{
    const token =localStorage.getItem("userToken");
    const soso = await axios.patch('https://ecommerce-node4.onrender.com/cart/incraseQuantity',
      {productId:productId},
      {
        headers:{
          Authorization:`Tariq__${token}`
        }
      }
    );
    setCart(prevCart=>{
      return prevCart.map(item =>{
        if(item.productId == productId){
          return{...item,quantity:item.quantity+1};
        }
        return item;
     
      })
    })
  }

  const decQty= async(productId)=>{
    const token =localStorage.getItem("userToken");
    if((item.quantity)> 0){
    const Response= await axios.patch('https://ecommerce-node4.onrender.com/cart/decraseQuantity',
      {productId:productId},
      {
        headers:{
          Authorization:`Tariq__${token}`
        }
      } );
    
  }
  console.log(Response);
}
 

  const remove =async(productId)=>{
    const token =localStorage.getItem("userToken");
    const Data= await axios.patch('https://ecommerce-node4.onrender.com/cart/removeItem',
      {productId:productId},
      {
        headers:{
          Authorization:`Tariq__${token}`
        }
      }  
    );
  }
   const clear=async(productId)=>{
    const token =localStorage.getItem("userToken");
    const daTa= await axios.patch('https://ecommerce-node4.onrender.com/cart/clear',
      {productId:productId},
      {
        headers:{
          Authorization:`Tariq__${token}`
        }
      } 
    

    ) ;
  
   }
   

 
  return (
   <section>
    <h2>Your Cart</h2>
    <Table striped bordered hover>
      <thead>
        <tr>
        
          <th>Image</th>
          <th>Product Name</th>
          <th>Price</th>
          <th>Quantity</th>
  
          <th>Total</th>
        </tr>
      </thead>
      <tbody>
  {cart.map(item=>
    <tr key={item._id}>
        <td><img src={item.details.mainImage?.secure_url} width='50px'  /></td>
    <td>   {item.details.name}</td>
    <td>{item.details.finalPrice}$</td>
   
    <td>
    <button className='bg-secondary' onClick={()=>incQty(item.productId)}>+</button> 
    {item.quantity}
    <button className='bg-secondary' onClick={()=>decQty()}>-</button> 
    <button className='bg-secondary' onClick={()=>remove(item.productId)}>Remove</button> 
    <button onClick={()=>clear(item.productId)} className='bg-secondary m-auto'> clear Cart</button>
    </td>
   
    <td>{item.quantity*item.details.finalPrice}</td>


    </tr>
  
   
    
     )
     
     }
<Link to={'/order'} >CHECKOUT </Link>
      
      </tbody>
    </Table>

   </section>
  )
}
