import React, { useState } from 'react'
import FloatingLabel from 'react-bootstrap/FloatingLabel';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import { useForm } from 'react-hook-form';
import axios from 'axios';

export default function Order() {
      const {register,handleSubmit} = useForm();
     const [isLoading,setIsloading]=useState(false);
      
        const placeOrder=async(value)=>{
            const token =localStorage.getItem("userToken");
            if (!token) {
              alert("Please,Login to create order");
              return; 
          }
            setIsloading(true);
         
            try{
              console.log("Order Data:", value,token);
                const response= await axios.post('http://localhost:3000/order',value,
                    {
                        headers:{
                          Authorization:`Tariq__${token}`
                        }
                      } 
                );
                console.log(response.data);
             
            }catch(error){
                console.log("error placing order",error);
            }finally{
                setIsloading(false);
            }
        
           
        }
  return (
    <>
    <div>
        <Form onSubmit={handleSubmit(placeOrder)}>
        <FloatingLabel
        controlId="floatingInput"
        label="couponName"
        className="mb-3"
      >
        <Form.Control type="text" {...register("couponName")}  />
      </FloatingLabel>

      <FloatingLabel
        controlId="floatingInput"
        label=" address"
        className="mb-3"
      >
        <Form.Control type="text" {...register("address",{required:"address is required"})} />
      </FloatingLabel>

      <FloatingLabel
        controlId="floatingInput"
        label="phone"
        className="mb-3"
      >
        <Form.Control type="number" {...register("phone",{required:"phone is required"})} />
      </FloatingLabel>

      <Button type='submit' disabled={isLoading}>{isLoading?"Loading...":"Place Order"}</Button>

        </Form>
        </div>
        </>
  )
}
